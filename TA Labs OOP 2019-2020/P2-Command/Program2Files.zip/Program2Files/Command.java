public interface Command
{
   
}
